public class Main {
    public static void main(String[] args) {
        System.out.println("<font style='color: red'>*** ERRORE AVVIO SERVER ***</font>");
    }
}